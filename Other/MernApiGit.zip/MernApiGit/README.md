## To Run this Project via NPM follow below:

```bash
npm install
npm run dev
```